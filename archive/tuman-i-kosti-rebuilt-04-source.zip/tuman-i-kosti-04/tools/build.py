"""Build a self-contained HTML game; no network or third-party Python packages."""
from pathlib import Path
import base64,json
root=Path(__file__).resolve().parents[1]
s=(root/'template.html').read_text()
assets='const ATLAS_URL='+json.dumps('data:image/png;base64,'+base64.b64encode((root/'assets/atlas.png').read_bytes()).decode())+';\nconst ATLAS_META='+(root/'assets/atlas.json').read_text()+';'
s=s.replace('/*__ASSETS__*/',assets).replace('/*__GAME__*/',(root/'src/game.js').read_text()).replace('/*__PAINTER__*/',(root/'src/painter.js').read_text())
(root/'index.html').write_text(s)
print('Built index.html:',len(s.encode()),'bytes')
