"""Playable combat experiment: real UI actions, damage rules, AI and isolation."""
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from playwright.sync_api import sync_playwright
import os
ROOT=Path(__file__).resolve().parents[1]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT)))
Thread(target=server.serve_forever,daemon=True).start()
base=f'http://127.0.0.1:{server.server_port}'
passed=[]
def ok(text):passed.append(text);print('PASS:',text,flush=True)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 p=browser.new_page(viewport={'width':1440,'height':1080});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto(base+'/battle-lab.html');p.uncheck('#motion')
 assert p.locator('.tile').count()==63
 assert p.evaluate('Lab.state.units.length')==8
 assert p.evaluate('Lab.state.units.every(u=>u.ap===3)')
 ok('Standalone battle starts with four heroes on each side and three AP')
 # Click a reachable tile: charge exactly the visible path cost.
 p.locator('[data-q="2"][data-r="1"]').click()
 assert p.evaluate('Lab.state.units[0].q===2&&Lab.state.units[0].ap===2')
 p.locator('[data-q="1"][data-r="1"]').click()
 assert p.evaluate('Lab.state.units[0].ap===1')
 p.locator('[data-q="4"][data-r="1"]').click()
 assert p.evaluate('Lab.state.units[0].ap===1&&Lab.state.units[0].q===1')
 ok('UI movement spends path AP and rejects destinations over budget')
 p.evaluate("Lab.reset('cover');Lab.state.units[0].q=2;Lab.state.units[0].r=2;Lab.render()")
 result=p.evaluate("()=>{const u=Lab.state.units[0],p=Lab.paths(u);return {mud:p.get('3,2').cost,rock:p.has('4,2')}}")
 assert result=={'mud':2,'rock':False}
 p.evaluate("Lab.state.units[0].slow=1")
 assert p.evaluate("Lab.paths(Lab.state.units[0]).get('3,2').cost")==3
 ok('Mud and slow use weighted paths; rocks cannot be entered')
 # Ranged cover and LOS; forecast matches every sampled hit.
 result=p.evaluate('''()=>{Lab.reset('cover');const u=Lab.state.units[1],t=Lab.state.units[5];Object.assign(u,{q:1,r:1});Object.assign(t,{q:3,r:1});const cover=Lab.forecast(u,t,'attack');Lab.state.tiles['3,1'].kind='plain';const plain=Lab.forecast(u,t,'attack');Lab.state.tiles['2,1'].kind='rock';return {cover,plain,blocked:Lab.forecast(u,t,'attack')}}''')
 assert result['plain']['lo']-result['cover']['lo']==2
 assert not result['blocked']['ok']
 result=p.evaluate('''()=>{const hits=[];for(let i=0;i<25;i++){Lab.reset();const u=Lab.state.units[0],t=Lab.state.units[4];t.q=2;t.r=1;const f=Lab.forecast(u,t,'attack'),before=t.hp;Lab.state.seed=i*197;Lab.apply(u,t,'attack');hits.push(before-t.hp>=f.lo&&before-t.hp<=f.hi&&u.ap===2)}return hits.every(Boolean)}''')
 assert result
 ok('Cover and line of sight affect real attacks; guaranteed hits stay inside forecast')
 p.evaluate("Lab.reset();Lab.guard(Lab.state.units[4]);Lab.state.units[0].q=5;Lab.render()")
 f=p.evaluate("Lab.forecast(Lab.state.units[0],Lab.state.units[4],'attack')")
 assert f['defense']==6 and f['lo']==1 and f['hi']==3
 assert not p.evaluate('Lab.guard(Lab.state.units[4])')
 ok('Guard adds three defense, cannot stack, and retains minimum one damage')
 # Use real UI to heal a downed hero then spend his only AP.
 p.select_option('#scenario','rescue');p.click('[data-action="heal"]');p.locator('[data-q="4"][data-r="3"]').hover()
 assert 'Подъём с 1 ОД' in p.inner_text('#forecast')
 p.locator('[data-q="4"][data-r="3"]').click()
 assert p.evaluate('Lab.state.units[0].hp===10&&Lab.state.units[0].ap===1&&Lab.state.units[3].ap===1&&Lab.state.units[3].heals===1')
 p.locator('[data-select="p0"]').click();p.click('[data-action="attack"]');p.locator('[data-q="5"][data-r="3"]').click()
 assert p.evaluate('Lab.state.units[0].ap===0')
 assert p.locator('[data-action="attack"]').is_disabled()
 ok('UI rescue heals ten HP and permits exactly one action after revival')
 # Real special action: cooldown and armor effect expire at advertised time.
 p.evaluate("Lab.reset();Lab.state.units[4].q=2;Lab.state.units[4].r=1;Lab.render()")
 p.click('[data-action="break"]');p.locator('[data-q="2"][data-r="1"]').click()
 assert p.evaluate('Lab.state.units[0].ap===1&&Lab.state.units[0].cooldown===3&&Lab.state.units[4].exposed===1')
 p.click('#end');p.wait_for_function('!Lab.busy')
 assert p.evaluate('Lab.state.round===2&&Lab.state.units[4].exposed===0')
 assert p.locator('[data-action="break"]').is_disabled()
 p.click('#end');p.wait_for_function('!Lab.busy')
 assert p.evaluate('Lab.state.round===3')
 assert p.locator('[data-action="break"]').is_enabled()
 ok('Special attack spends two AP, debuff expires after target turn, cooldown lasts two rounds')
 p.evaluate("Lab.reset('cover')")
 p.click('#end');p.wait_for_function('!Lab.busy')
 assert p.evaluate('Lab.state.units.filter(u=>u.side===1).some(u=>u.q<6)')
 assert p.evaluate("Lab.state.units.every(u=>Lab.state.tiles[u.q+','+u.r].kind!=='rock')")
 assert p.evaluate('Lab.state.units.every(u=>u.ap>=0)')
 ok('Enemy squad navigates terrain without illegal movement or negative AP')
 # Restart while an animated enemy turn is pending must cancel old work.
 p.check('#motion');p.click('#end');p.click('#restart');p.wait_for_timeout(700)
 assert p.evaluate('Lab.state.round===1&&Lab.state.side===0&&!Lab.busy&&Lab.state.actions===0')
 p.uncheck('#motion')
 ok('Restart cancels pending animated AI actions')
 # Victory and stress are actual rules, not labels.
 p.evaluate("Lab.reset();for(const u of Lab.state.units.filter(u=>u.side===1)){u.hp=0;u.ap=0};Lab.state.units[4].hp=1;Lab.state.units[4].q=2;Lab.state.units[4].r=1;Lab.state.units[3].hp=0;Lab.state.units[3].ap=0;Lab.render()")
 p.click('[data-action="attack"]');p.locator('[data-q="2"][data-r="1"]').click()
 assert p.evaluate('Lab.state.winner===0&&Lab.state.units[3].hp===1')
 assert p.locator('#result').is_visible() and p.locator('#end').is_disabled()
 p.evaluate("Lab.reset();Lab.state.units[0].stress=60")
 p.click('#end');p.wait_for_function('!Lab.busy')
 assert p.evaluate('Lab.state.units[0].ap===2')
 ok('Battle terminates on defeat of a squad; winners revive allies; stress reduces AP')
 # File copy must restart cleanly and work with no network.
 with p.expect_download() as dl:p.click('#download')
 dl.value.save_as('/tmp/battle-lab-copy.html')
 copy=browser.new_page();copy.route('**/*',lambda route:route.abort());copy.set_content(Path('/tmp/battle-lab-copy.html').read_text())
 assert copy.evaluate('Lab.state.round===1&&Lab.state.units.length===8')
 copy.close()
 p.locator('summary').last.click()
 with p.expect_download() as dl:p.click('#report')
 import json
 result=json.loads(Path(dl.value.path()).read_text())
 assert result['version']=='0.8.1-lab' and result['scenario']=='equal'
 ok('Standalone HTML backup boots offline; feedback export contains actual metrics')
 # Companion main game must retain its state across lab use.
 p.goto(base);p.wait_for_function('Game.painter.ready');p.get_by_role('button',name='Пробный бой 4 на 4',exact=True).click();p.frame_locator('#battleLabOverlay iframe').locator('#phase').wait_for();p.locator('#battleLabOverlay > button').click();p.evaluate('Game.newGame(813);Game.fx.configure({enabled:false})')
 before=p.evaluate('JSON.stringify(Game.state)');p.evaluate("document.getElementById('openBattleLab').click()")
 frame=p.frame_locator('#battleLabOverlay iframe');frame.locator('#scenario').select_option('cover');frame.locator('#end').click()
 p.wait_for_timeout(300);p.locator('#battleLabOverlay > button').click()
 assert p.evaluate('JSON.stringify(Game.state)')==before
 assert not p.locator('#battleLabOverlay').count()
 ok('Integrated lab opens and closes without modifying the main campaign or saves')
 p.goto(base+'/battle-lab.html');p.uncheck('#motion')
 summaries=p.evaluate("""async()=>{const results=[];for(const scenario of ['equal','cover','rescue']){Lab.reset(scenario);let rounds=0;while(Lab.state.winner===null&&rounds++<25){for(const u of Lab.state.units.filter(u=>u.side===0&&u.hp>0)){document.querySelector('[data-select="'+u.id+'"]').click();let n=0;while(u.ap>0&&Lab.state.winner===null&&n++<5){let done=false;if(u.type==='acolyte'){const t=Lab.state.units.filter(t=>t.side===0&&t.hp<=t.max-10).sort((a,b)=>a.hp-b.hp).find(t=>!Lab.check(u,t,'heal'));if(t)done=Lab.apply(u,t,'heal')}if(!done){const options=[];for(const t of Lab.state.units.filter(t=>t.side===1&&t.hp>0)){const f=Lab.forecast(u,t,'attack');if(f.ok)options.push({t,f})}options.sort((a,b)=>a.t.hp-b.t.hp);if(options.length)done=Lab.apply(u,options[0].t,'attack')}if(!done){const dest=Lab.approach(u,Lab.state.units.filter(t=>t.side===1&&t.hp>0));if(dest){await Lab.chooseTile(dest.q,dest.r);done=true}}if(!done)break}}if(Lab.state.winner===null)await Lab.endTurn()}results.push({scenario,winner:Lab.state.winner,round:Lab.state.round,actions:Lab.state.actions})}return results}""")
 assert all(r['winner'] is not None and r['round']<=25 for r in summaries),summaries
 print('Battle completion metrics:',summaries,flush=True)
 ok('All three scenarios reach a battle result through legal actions and enemy turns')
 p.goto(base+'/battle-lab.html');p.select_option('#scenario','cover');p.screenshot(path='/tmp/battle-lab-cover.png',full_page=True)
 p.set_viewport_size({'width':390,'height':844});p.screenshot(path='/tmp/battle-lab-mobile.png',full_page=True)
 assert p.evaluate('document.documentElement.scrollWidth<=innerWidth')
 assert not errors,errors
 ok('Desktop/mobile layouts have no horizontal overflow or browser errors')
 browser.close()
server.shutdown()
print(f'{len(passed)} battle lab scenarios passed.')
