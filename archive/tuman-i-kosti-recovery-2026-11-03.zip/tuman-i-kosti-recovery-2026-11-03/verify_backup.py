from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest['files']:
    path=root/item['path']
    if not path.is_file():errors.append('MISSING '+item['path']);continue
    if hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:errors.append('CHANGED '+item['path'])
if errors:raise SystemExit('\n'.join(errors))
print('OK:',len(manifest['files']),'files match SHA-256 checksums.')
